package com.devcicero.devcicero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevciceroApplicationTests {

	@Test
	void contextLoads() {
	}

}
