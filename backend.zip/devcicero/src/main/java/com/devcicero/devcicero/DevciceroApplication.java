package com.devcicero.devcicero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevciceroApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevciceroApplication.class, args);
	}

}
